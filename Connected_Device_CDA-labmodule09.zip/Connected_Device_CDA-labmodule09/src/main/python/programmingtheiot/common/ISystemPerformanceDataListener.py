#####
# 
# This class is part of the Programming the Internet of Things
# project, and is available via the MIT License, which can be
# found in the LICENSE file at the top level of this repository.
# 
# Copyright (c) 2020 by Andrew D. King
# 

from programmingtheiot.data.SystemPerformanceData import SystemPerformanceData

class ISystemPerformanceDataListener():
	"""
	Interface definition for system performance data listener clients.
	
	"""
	
	def onSystemPerformanceDataUpdate(self, data: SystemPerformanceData) -> bool:
		"""
		Callback function to handle a system performance message packaged as
		SystemPerformanceData object.
		
		@param data The SystemPerformanceData message received.
		@return bool True on success; False otherwise.
		"""
		pass
	